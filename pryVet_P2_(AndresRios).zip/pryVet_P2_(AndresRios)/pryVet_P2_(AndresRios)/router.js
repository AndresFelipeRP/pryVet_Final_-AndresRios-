//invocar express
const express = require('express');
const router = express.Router();

const conexion = require('./database/db');

router.get(['/', '/login'], (req, res)=>{
    res.render('login', {mensaje: '' });
    
});

router.get('/index', (req, res)=>{
    res.render('index');
    
});

router.get('/acercade', (req, res)=>{
    res.render('acercade');
});

//cliente
router.get('/cliente', (req, res)=>{
    
    conexion.query('SELECT * FROM cliente', (error, results)=> {
        if(error){
            throw error;
        }else{
            res.render('cliente', {results: results});
        }
    }); 
});

//Ruta para crear clientes
router.get('/create', (req, res)=>{
    res.render('create');
});

//ruta de editar cliente
router.get('/edit/:cliente_id', (req, res)=> {
    const cliente_id = req.params.cliente_id;
    conexion.query('SELECT * FROM cliente WHERE cliente_id=?', [cliente_id], (error, results)=>{
        if(error){
            throw error;
        }else{
            res.render('edit', {cliente: results[0]});
        }
    });
});

//ruta para eliminar el cliente
router.get('/delete/:cliente_id', (req, res)=> {
    const cliente_id = req.params.cliente_id;
     conexion.query('DELETE FROM cliente WHERE cliente_id = ?', [cliente_id], (error, results)=>{
        if(error){
            throw error;
        }else{
            res.redirect('/cliente');
        }
    });
});

//mascota
router.get('/mascota', (req, res) => {
    conexion.query('SELECT * FROM mascota', (error, mascotas) => {
        if (error) {
            throw error;
        } else {
            if (mascotas.length === 0) {
                res.render('mascota', { mascotas: mascotas, citasPorMascota: [] });
            } else {
                const citasPromises = mascotas.map(mascota => {
                    return new Promise((resolve, reject) => {
                        conexion.query('SELECT * FROM citas WHERE mascota_id = ?', [mascota.mascota_id], (error, citasResults) => {
                            if (error) {
                                reject(error);
                            } else {
                                resolve({
                                    mascotaId: mascota.mascota_id,
                                    tieneCitas: citasResults.length > 0
                                });
                            }
                        });
                    });
                });
                Promise.all(citasPromises)
                    .then(citasPorMascota => {
                        res.render('mascota', { mascotas: mascotas, citasPorMascota: citasPorMascota });
                    })
                    .catch(error => {
                        console.error(error);
                        res.status(500).send('Error interno del servidor');
                    });
            }
        }
    });
});


//ruta para mascotas
router.get('/creamascota/:cliente_id', (req, res)=> {
    const cliente_id = req.params.cliente_id;
    conexion.query('SELECT * FROM cliente WHERE cliente_id=?', [cliente_id], (error, results)=>{
        if(error){
            throw error;
        }else{
            res.render('creamascota', {cliente: results[0]});
        }
    });
});

//ruta para eliminar mascota
router.get('/deletemascota/:mascota_id', (req, res)=> {
    const mascota_id = req.params.mascota_id;
     conexion.query('DELETE FROM mascota WHERE mascota_id = ?', [mascota_id], (error, results)=>{
        if(error){
            throw error;
        }else{
            res.redirect('/mascota');
        }
    });
});

//ruta de editar mascota
router.get('/editmascota/:mascota_id', (req, res)=> {
    const mascota_id = req.params.mascota_id;
    conexion.query('SELECT * FROM mascota WHERE mascota_id=?', [mascota_id], (error, results)=>{
        if(error){
            throw error;
        }else{
            res.render('editmascota', {mascota: results[0]});
        }
    });
});

// Empleados
router.get('/empleado', (req, res)=>{
    
    conexion.query('SELECT * FROM empleado', (error, results)=> {
        if(error){
            throw error;
        }else{
            res.render('empleado', {results: results});
        }
    }); 
});

router.get('/addempleado', (req, res)=>{
    res.render('addempleado');
});

router.get('/editempleado/:empleado_id', (req, res)=> {
    const empleado_id = req.params.empleado_id;
    conexion.query('SELECT * FROM empleado WHERE empleado_id=?', [empleado_id], (error, results)=>{
        if(error){
            throw error;
        }else{
            res.render('editempleado', {empleado: results[0]});
        }
    });
});

router.get('/deleteempleado/:empleado_id', (req, res)=> {
    const empleado_id = req.params.empleado_id;
     conexion.query('DELETE FROM empleado WHERE empleado_id = ?', [empleado_id], (error, results)=>{
        if(error){
            throw error;
        }else{
            res.redirect('/empleado');
        }
    });
});


//citas
router.get('/citas/:mascota_id', (req, res)=>{
    const mascota_id = req.params.mascota_id;
    conexion.query('SELECT * FROM citas WHERE mascota_id =?', [mascota_id],(error, results)=> {
        if(error){
            throw error;
        }else{
            res.render('citas', { mascota_id: mascota_id, results: results });
        }
    }); 
});

router.get('/crearcitas/:mascota_id', (req, res) => {
    const mascota_id = req.params.mascota_id;
    conexion.query('SELECT * FROM mascota WHERE mascota_id=?', [mascota_id], (error, results) => {
        if (error) {
            throw error;
        } else {
            res.render('crearcitas', { mascota: results[0] });
        }
    });
});

router.get('/editcitas/:cita_id', (req, res)=> {
    const cita_id = req.params.cita_id;
    conexion.query('SELECT * FROM citas WHERE cita_id=?', [cita_id], (error, results)=>{
        if(error){
            throw error;
        }else{
            res.render('editcitas', {citas: results[0]});
        }
    });
});

router.get('/deletecitas/:cita_id/:mascota_id', (req, res) => {
    const cita_id = req.params.cita_id;
    const mascota_id = req.params.mascota_id;
    conexion.query('DELETE FROM citas WHERE cita_id = ?', [cita_id], (error, results) => {
        if (error) {
            throw error;
        } else {
            res.redirect(`/citas/${mascota_id}`);
        }
    });
});

//Inventario
router.get('/inventario', (req, res)=>{
    
    conexion.query('SELECT * FROM inventario', (error, results)=> {
        if(error){
            throw error;
        }else{
            res.render('inventario', {results: results});
        }
    }); 
});

router.get('/crearinventario', (req, res)=>{
    res.render('crearinventario');
});

router.get('/editinventario/:producto_id', (req, res)=> {
    const producto_id = req.params.producto_id;
    conexion.query('SELECT * FROM inventario WHERE producto_id=?', [producto_id], (error, results)=>{
        if(error){
            throw error;
        } else {
            res.render('editinventario', {inventario: results[0]});
        }
    });
});


router.get('/deleteinventario/:producto_id', (req, res)=> {
    const producto_id = req.params.producto_id;
     conexion.query('DELETE FROM inventario WHERE producto_id = ?', [producto_id], (error, results)=>{
        if(error){
            throw error;
        }else{
            res.redirect('/inventario');
        }
    });
});

//Metodos para el crud
const crud = require('./controllers/crud');
router.post('/save', crud.save);
router.post('/update', crud.update);
router.post('/save2', crud.save2);
router.post('/update2', crud.update2);
router.post('/save3', crud.save3);
router.post('/update3', crud.update3);
router.post('/save4', crud.save4);
router.post('/update4', crud.update4);
router.post('/save5', crud.save5);
router.post('/update5', crud.update5);


router.post('/loginn', crud.loginn);
router.post('/logout', crud.logout);




//exportar este archivo
module.exports = router;



