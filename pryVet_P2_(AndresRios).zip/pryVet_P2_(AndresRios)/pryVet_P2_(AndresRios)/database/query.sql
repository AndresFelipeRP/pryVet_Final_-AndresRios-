-- Eliminar la base de datos veterinaria si existe
DROP DATABASE IF EXISTS veterinaria;

-- Crear la base de datos veterinaria
CREATE DATABASE veterinaria;

-- Usar la base de datos veterinaria
USE veterinaria;

-- Crear la tabla de clientes
CREATE TABLE cliente (
    cliente_id INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(30) NOT NULL,
    email VARCHAR(30),
    telefono VARCHAR(15)
);

-- Crear la tabla de empleados
CREATE TABLE empleado (
    empleado_id INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(30) NOT NULL,
    ocupacion VARCHAR(30) NOT NULL,
    email VARCHAR(30),
    contraseña VARCHAR(30),
    rol VARCHAR(30),
    telefono VARCHAR(15)
);

-- Crear la tabla de mascotas
CREATE TABLE mascota (
    mascota_id INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(30) NOT NULL,
    especie VARCHAR(30),
    cliente_id INT,
    FOREIGN KEY (cliente_id) REFERENCES cliente(cliente_id) ON DELETE CASCADE
);

CREATE TABLE inventario (
    producto_id INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(30) NOT NULL,
    cantidad VARCHAR(30),
    proveedor VARCHAR(30) NOT NULL,
    caducidad VARCHAR(30) NOT NULL
);

-- Crear la tabla de citas
CREATE TABLE citas (
    cita_id INT AUTO_INCREMENT PRIMARY KEY,
    fecha DATE NOT NULL,
    hora TIME NOT NULL,
    motivo VARCHAR(255),
    mascota_id INT,
    FOREIGN KEY (mascota_id) REFERENCES mascota(mascota_id) ON DELETE CASCADE
);

-- Insertar registros en la tabla cliente
INSERT INTO cliente (nombre, email, telefono) VALUES
    ('Santiago', 'Santiago@gmail.com', '3136474881'),
    ('Andres', 'Andres@gmail.com', '3012853456'),
    ('Carlos', 'Carlos@gmail.com', '3187654321'),
    ('Ana', 'Ana@gmail.com', '3156789012'),
    ('Luisa', 'Luisa@gmail.com', '3001234567');

-- Insertar registros en la tabla mascota
INSERT INTO mascota (nombre, especie, cliente_id) VALUES
    ('Lola', 'Perro', 1),
    ('Firulais', 'Gato', 1),
    ('Carolo', 'Perro', 1),
    ('Aquiles', 'Gato', 2),
    ('Pichulita', 'Conejo', 2),
    ('Nina', 'Perro', 3),
    ('Milo', 'Gato', 3),
    ('Pelusa', 'Perro', 4),
    ('Simba', 'Gato', 4),
    ('Coco', 'Perro', 5);

-- Insertar registros en la tabla empleado
INSERT INTO empleado (nombre, ocupacion, email, contraseña, rol, telefono) VALUES
    ('Juan Pérez', 'Veterinario', 'juan@example.com', 'Password1', 'admin', '3124567890'),
    ('Ana Gómez', 'Asistente Veterinario', 'ana@example.com', 'Password2', 'cliente', '3186543210'),
    ('Carlos López', 'Médico Veterinario', 'carlos@example.com', 'Password3', 'cliente', '3151234567'),
    ('María Rodríguez', 'Recepcionista', 'maria@example.com', 'Password4', 'cliente', '3132223333'),
    ('Pedro Martinez', 'Enfermero Veterinario', 'pedro@example.com', 'Password5', 'admin', '3178887777'),
    ('Santiago', 'Ingeniero', 'santirestrepomejia@gmail.com', 'Santiago123', 'admin', '3136474881');

-- Insertar registros en la tabla inventario
INSERT INTO inventario (nombre, cantidad, Proveedor, caducidad) VALUES
('Paracetamol', '10', 'ProveedorA', '2023-01-01'),
('Ibuprofeno', '15', 'ProveedorB', '2023-02-15'),
('Aspirina', '20', 'ProveedorC', '2023-03-20'),
('Omeprazol', '5', 'ProveedorA', '2023-04-10'),
('Amoxicilina', '12', 'ProveedorB', '2023-05-05');


-- Insertar registros en la tabla citas
INSERT INTO citas (fecha, hora, motivo, mascota_id) VALUES 
  ('2023-11-18', '10:00:00', 'Control de rutina', 1),
  ('2023-11-19', '15:30:00', 'Vacunación anual', 1),
  ('2023-11-20', '11:45:00', 'Chequeo dental', 2),
  ('2023-11-21', '14:15:00', 'Revisión general', 3),
  ('2023-11-22', '16:30:00', 'Desparasitación', 4),
  ('2023-11-23', '12:00:00', 'Consulta de comportamiento', 5),
  ('2023-11-24', '09:30:00', 'Vacunación preventiva', 6),
  ('2023-11-25', '17:00:00', 'Cirugía esterilización', 7),
  ('2023-11-26', '13:45:00', 'Control de peso', 8),
  ('2023-11-27', '11:00:00', 'Consulta de ojos', 9);
