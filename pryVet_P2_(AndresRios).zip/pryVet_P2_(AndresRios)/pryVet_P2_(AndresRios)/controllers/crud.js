const conexion = require('../database/db');

//clientes
exports.save = (req, res)=>{
    const nombre = req.body.nombre;
    const email = req.body.email;
    const telefono = req.body.telefono;
    conexion.query('INSERT INTO cliente SET ?', {nombre:nombre, email:email, telefono:telefono}, (error, results)=> {
        if(error){
            console.log(error);
        }else{
           res.redirect('/cliente');
        }
    })
}

exports.update = (req, res)=>{
    const cliente_id = req.body.cliente_id;
    const nombre = req.body.nombre;
    const email = req.body.email;
    const telefono = req.body.telefono;
    conexion.query('UPDATE cliente SET ? WHERE cliente_id = ?', [{nombre:nombre, email:email, telefono:telefono}, cliente_id], (error, results)=>{
        if(error){
            console.log(error);
        }else{
           res.redirect('/cliente');
        }
    });
}

//empleados
exports.save3 = (req, res)=>{
    const nombre = req.body.nombre;
    const ocupacion = req.body.ocupacion;
    const rol = req.body.rol;
    const email = req.body.email;
    const contraseña = req.body.contraseña;
    const telefono = req.body.telefono;
    conexion.query('INSERT INTO empleado SET ?', {nombre:nombre, ocupacion:ocupacion, email:email, contraseña:contraseña, rol:rol, telefono:telefono}, (error, results)=> {
        if(error){
            console.log(error);
        }else{
           res.redirect('login');
        }
    })
}

exports.update3 = (req, res)=>{
    const empleado_id = req.body.empleado_id;
    const nombre = req.body.nombre;
    const ocupacion = req.body.ocupacion;
    const email = req.body.email;
    const contraseña = req.body.contraseña;
    const rol = req.body.rol;
    const telefono = req.body.telefono;
    conexion.query('UPDATE empleado SET ? WHERE empleado_id = ?', [{nombre:nombre, ocupacion:ocupacion, email:email, contraseña:contraseña, rol:rol, telefono:telefono}, empleado_id], (error, results)=>{
        if(error){
            console.log(error);
        }else{
           res.redirect('/empleado');
        }
    });
}


//mascotas
exports.save2 = (req, res)=>{
    const cliente_id = req.body.cliente_id;
    const nombreMas = req.body.nombreMas;
    const especie = req.body.especie;
    conexion.query('INSERT INTO mascota SET ?', {nombre:nombreMas, especie:especie, cliente_id:cliente_id}, (error, results)=> {
        if(error){
            console.log(error);
        }else{
           res.redirect('/mascota');
        }
    })
}

exports.update2 = (req, res)=>{
    const mascota_id = req.body.mascota_id;
    const nombreMas = req.body.nombreMas;
    const especie = req.body.especie;
    const cliente_id = req.body.cliente_id;
    conexion.query('UPDATE mascota SET ? WHERE mascota_id = ?', [{nombre:nombreMas, especie:especie, cliente_id:cliente_id}, mascota_id], (error, results)=>{
        if(error){
            console.log(error);
        }else{
           res.redirect('/mascota');
        }
    });
}

//citas
exports.save4 = (req, res)=>{
    const mascota_id = req.body.mascota_id;
    const fecha = req.body.fecha;
    const hora = req.body.hora;
    const motivo = req.body.motivo;
    conexion.query('INSERT INTO citas SET ?', {fecha:fecha, hora:hora, motivo:motivo, mascota_id:mascota_id}, (error, results)=> {
        if(error){
            console.log(error);
        }else{
            res.redirect(`/citas/${mascota_id}`);
        }
    })
}

exports.update4 = (req, res) => {
    const mascota_id = req.body.mascota_id;
    const fecha = req.body.fecha;
    const hora = req.body.hora;
    const motivo = req.body.motivo;
    const cita_id = req.body.cita_id;
    conexion.query('UPDATE citas SET ? WHERE cita_id = ?', [{ fecha: fecha, hora: hora, motivo: motivo, mascota_id: mascota_id }, cita_id], (error, results) => {
        if (error) {
            console.log(error);
        } else {
            res.redirect(`/citas/${mascota_id}`);
        }
    });
};

//Inventario
exports.save5 = (req, res)=>{
    const nombre = req.body.nombre;
    const cantidad = req.body.cantidad;
    const proveedor = req.body.proveedor;
    const caducidad = req.body.caducidad;
    conexion.query('INSERT INTO inventario SET ?', {nombre:nombre, cantidad:cantidad, proveedor:proveedor, caducidad:caducidad}, (error, results)=> {
        if(error){
            console.log(error);
        }else{
           res.redirect('inventario');
        }
    })
}

exports.update5 = (req, res)=>{
    const producto_id = req.body.producto_id;
    const nombre = req.body.nombre;
    const cantidad = req.body.cantidad;
    const proveedor = req.body.proveedor;
    const caducidad = req.body.caducidad;
    conexion.query('UPDATE inventario SET ? WHERE producto_id = ?', [{nombre:nombre, cantidad:cantidad, proveedor:proveedor, caducidad:caducidad}, producto_id], (error, results)=>{
        if(error){
            console.log(error);
        }else{
           res.redirect('inventario');
        }
    });
}

//login
// En tu ruta de login
exports.loginn = (req, res) => {
    const nombre = req.body.nombre;
    const password = req.body.password;

    conexion.query('SELECT * FROM empleado WHERE nombre = ? AND contraseña = ?', [nombre, password], (error, results) => {
        if (error) {
            console.log(error);
            return res.status(500).send('Error en el servidor');
        }

        // Verificar si se encontró un usuario con el nombre y contraseña dados
        if (results.length > 0) {
            const usuario = results[0];

            // Almaceno el usuario en req.session
            req.session.usuario = usuario;

            // Redireccionar a la página de éxito
            res.redirect('index');
        } else {
            // No se encontró un usuario con el nombre y contraseña dados
            res.render('login', {mensaje: '*Usuario o contraseña incorrectos*'});
        }
    });
};

// Logout
exports.logout = (req, res) => {
    req.session.destroy((error) => {
        if (error) {
            console.log(error);
            return res.status(500).send('Error al cerrar sesión');
        }
    
        // Redireccionar a la página de inicio de sesión o a donde desees
        res.redirect('login');
    });
};
