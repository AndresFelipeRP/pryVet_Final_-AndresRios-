//invocar express
const express = require('express');
const session = require('express-session');
const crypto = require('crypto');
const app = express();

// Genera una cadena secreta aleatoria de 32 bytes
const secret = crypto.randomBytes(32).toString('hex');

// Configuración de express-session
app.use(session({
  secret: secret,
  resave: false,
  saveUninitialized: true,
  cookie: { 
    secure: false,
    maxAge: 1000 * 60 * 60, // Duración de la sesión en milisegundos (1 hora en este caso)
  },
}));

app.use((req, res, next) => {
    res.locals.usuario = req.session.usuario;
  
    // Llama a next() para pasar al siguiente middleware
    next();
  });

  app.use((req, res, next) => {
    if (req.session && req.session.usuario && req.session.cookie.expires < Date.now()) {
      // La sesión ha expirado, destruir la sesión expirada
      req.session.destroy((err) => {
        if (err) {
          console.error('Error al destruir la sesión:', err);
        }
        // Redirigir a la página de inicio de sesión
        res.redirect('login');
      });
    } else {
      // Llamar a next() para pasar al siguiente middleware en la cadena
      next();
    }
  });

  //motor de platillas
  app.set('view engine', 'ejs');

//capturar los datos de los formularios
app.use(express.urlencoded({extended:false}));
app.use(express(express.json));

app.use('/', require('./router.js'));

app.listen(3000, () => {
    console.log('SERVER corriendo en http://localhost:3000');
});